export class ApiError extends Error {
  constructor(message, status) {
    super(message);
    this.name = "ApiError";
    this.status = status;
  }
}

async function request(path, { method = "GET", body, form } = {}) {
  // Hub state must never be served stale from the browser cache.
  const options = { method, cache: "no-store", headers: {} };
  if (form !== undefined) {
    const params = form instanceof URLSearchParams ? form : new URLSearchParams(form);
    options.headers["Content-Type"] = "application/x-www-form-urlencoded";
    options.body = params.toString();
  } else if (body !== undefined) {
    options.headers["Content-Type"] = "application/json";
    options.body = JSON.stringify(body);
  }

  let response;
  try {
    response = await fetch(path, options);
  } catch (networkError) {
    // fetch rejects with a TypeError when no server answers at all.
    throw new ApiError("Sim server not reachable", 0);
  }

  const raw = await response.text();
  let json = null;
  if (raw) {
    try {
      json = JSON.parse(raw);
    } catch (_) {
      throw new ApiError(raw.slice(0, 120) || `HTTP ${response.status}`, response.status);
    }
  }

  if (!response.ok || (json && json.ok === false)) {
    const message = (json && (json.error || json.message)) || `HTTP ${response.status}`;
    throw new ApiError(message, response.status);
  }
  return json ?? { ok: true };
}

export function getConfig() {
  return request("/api/activity-config");
}

export function getState() {
  return request("/api/activity-state");
}

export function runActivity(activityId) {
  return request("/api/activity-run", {
    method: "POST",
    form: { activityId: String(activityId) },
  });
}

export function saveActivity({ baseRevision, activityList, mapList, functionList, syncRemote }) {
  return request("/api/activity-save", {
    method: "POST",
    body: { baseRevision, activityList, mapList, functionList, syncRemote },
  });
}

export function powerOff() {
  return runActivity(-1);
}

export function irSend({ deviceId, command, functionId, activityId }) {
  const form = {
    deviceId: String(deviceId),
    command: String(command),
  };
  if (functionId != null && functionId !== "") form.functionId = String(functionId);
  if (activityId != null && activityId !== "") form.activityId = String(activityId);
  return request("/api/ir-send", { method: "POST", form });
}

export function getSimEvents() {
  return request("/sim/events");
}
import * as api from "./api.js";

export const state = {
  config: null,
  configError: null,
  configLoaded: false,
  currentId: "", // "" unknown · "-1" everything off · "<id>" running
  stateError: null,
};

const subscribers = new Set();

export function subscribe(fn) {
  subscribers.add(fn);
  return () => subscribers.delete(fn);
}

function emit() {
  for (const fn of subscribers) fn(state);
}

export async function ensureConfig() {
  if (state.config || state.configError) return state;
  try {
    state.config = await api.getConfig();
    state.configError = null;
  } catch (error) {
    state.configError = error;
  }
  state.configLoaded = true;
  emit();
  return state;
}

export async function reloadConfig() {
  state.config = null;
  state.configError = null;
  state.configLoaded = false;
  emit();
  return ensureConfig();
}

function extractCurrentActivity(payload) {
  const raw =
    typeof payload === "string"
      ? payload
      : typeof payload?.reply === "string"
        ? payload.reply
        : payload
          ? JSON.stringify(payload)
          : "";

  let decoded = payload?.reply ?? payload;
  for (let attempt = 0; attempt < 3 && typeof decoded === "string"; attempt += 1) {
    const trimmed = decoded.trim();
    if (/^-?\d+$/.test(trimmed)) return trimmed;
    try {
      decoded = JSON.parse(trimmed);
    } catch (_) {
      break;
    }
  }

  const find = (value, depth = 0) => {
    if (depth > 8 || value == null) return "";
    if (typeof value === "object") {
      for (const [key, child] of Object.entries(value)) {
        if (/^(current)?activityid$/i.test(key) && /^-?\d+$/.test(String(child))) {
          return String(child);
        }
      }
      for (const [key, child] of Object.entries(value)) {
        if (/^result$/i.test(key) && /^-?\d+$/.test(String(child))) {
          return String(child);
        }
      }
      for (const child of Object.values(value)) {
        const found = find(child, depth + 1);
        if (found) return found;
      }
    } else if (typeof value === "string") {
      try {
        return find(JSON.parse(value), depth + 1);
      } catch (_) {
        return "";
      }
    }
    return "";
  };

  const structured = find(decoded);
  if (structured) return structured;

  const match =
    raw.match(/"(?:current)?activityId"\s*:\s*"?(-?\d+)"?/i) ||
    raw.match(/"result"\s*:\s*"?(-?\d+)"?/i);
  return match ? match[1] : "";
}

export async function refreshState() {
  try {
    const payload = await api.getState();
    state.currentId = extractCurrentActivity(payload);
    state.stateError = null;
  } catch (error) {
    state.stateError = error;
  }
  emit();
  return state;
}

export async function setRunning(id) {
  const target = String(id);
  try {
    await api.runActivity(target === "-1" ? -1 : Number(target));
    state.stateError = null;
    await refreshState();
    if (!state.currentId && !state.stateError) {
      state.currentId = target;
      emit();
    }
  } catch (error) {
    try {
      await refreshState();
    } catch (_) {}
    state.stateError = error;
    emit();
  }
  return state;
}

export function activities() {
  const list = state.config?.activityList?.Activities ?? [];
  return [...list].sort((a, b) => (a.ActivityOrder ?? 0) - (b.ActivityOrder ?? 0));
}

export function activityById(id) {
  return activities().find((a) => String(a["Id-"]) === String(id)) ?? null;
}

export function activityName(activity) {
  if (!activity) return "Unknown activity";
  return activity.Name || activity.ActivityDisplayName || `Activity ${activity["Id-"]}`;
}

const ACTIVITY_TYPE_LABELS = {
  1: "Watch TV",
  2: "Watch a movie",
  3: "Play a game",
  4: "Listen to music",
};

export function activityTypeLabel(activity) {
  return ACTIVITY_TYPE_LABELS[activity?.Type] ?? "Activity";
}

export function devices() {
  const raw = state.config?.deviceList?.DevicesWithFeatures ?? [];
  return raw.map((entry) => {
    const device = entry.Device ?? {};
    return {
      id: String(device["Id-"]),
      name: device.Name || device.FriendlyName || `Device ${device["Id-"]}`,
      manufacturer: device.Manufacturer ?? "",
      model: device.Model ?? "",
      type: device.DeviceType ?? "",
      commands: (entry.Commands ?? []).map((c) => ({
        name: c.Name,
        functionId: c["FunctionId-"],
        keyCode: c.KeyCode,
      })),
    };
  });
}

export function deviceById(id) {
  return devices().find((d) => d.id === String(id)) ?? null;
}

export function deviceName(id) {
  return deviceById(id)?.name ?? `Device ${id}`;
}

export function buttonMapsForActivity(id) {
  const maps = state.config?.mapList?.ButtonMaps ?? [];
  return maps.filter((m) => String(m["ActivityId-"]) === String(id));
}

export function counts() {
  return {
    activities: activities().length,
    devices: devices().length,
    buttonMaps: (state.config?.mapList?.ButtonMaps ?? []).length,
    revision: state.config?.revision ?? "—",
  };
}
/* Virtual remote geometry + alias matching, ported from codex_webui.c
 * (IR_REMOTE_BUTTONS, ir_command_key, ir_alias_match, ir_find_remote_command).
 *
 * Positions are percentages of the remote body: { x, y, w, h } map to
 * left/top/width/height on an absolutely positioned key. DOM order matches
 * the C array so overlapping d-pad keys stack the same way (OK is drawn
 * last and wins the center).
 */

export const REMOTE_BUTTONS = [
  { label: "Power off", aliases: "poweroff|power off|standby|shutdown|off|powertoggle|power toggle|power", x: 13.55, y: 0.45, w: 18.60, h: 3.35 },
  { label: "Music", aliases: "music|audio", x: 8.80, y: 6.85, w: 26.75, h: 5.10 },
  { label: "TV", aliases: "tv|television|watchtv|display", x: 35.50, y: 6.85, w: 27.10, h: 5.10 },
  { label: "Movie", aliases: "movie|video|media", x: 62.60, y: 6.85, w: 27.10, h: 5.10 },
  { label: "Rewind", aliases: "rewind|rev|skipback|previous track", x: 8.80, y: 14.90, w: 27.95, h: 5.25 },
  { label: "Play", aliases: "play", x: 41.45, y: 15.00, w: 16.25, h: 5.40 },
  { label: "Forward", aliases: "fastforward|forward|ffwd|next track|skipforward", x: 62.45, y: 14.85, w: 27.95, h: 5.30 },
  { label: "Record", aliases: "record|rec", x: 8.95, y: 21.80, w: 27.90, h: 5.35 },
  { label: "Pause", aliases: "pause", x: 41.45, y: 21.80, w: 16.25, h: 5.35 },
  { label: "Stop", aliases: "stop", x: 62.45, y: 21.80, w: 27.95, h: 5.35 },
  { label: "Red", aliases: "red", x: 9.30, y: 30.00, w: 18.60, h: 3.75 },
  { label: "Green", aliases: "green", x: 30.10, y: 30.00, w: 18.95, h: 3.75 },
  { label: "Yellow", aliases: "yellow", x: 51.80, y: 30.00, w: 18.15, h: 3.75 },
  { label: "Blue", aliases: "blue", x: 73.25, y: 30.00, w: 17.45, h: 3.75 },
  { label: "DVR", aliases: "dvr|recordings", x: 9.00, y: 36.95, w: 27.40, h: 5.05 },
  { label: "Guide", aliases: "guide|epg", x: 36.40, y: 36.95, w: 26.40, h: 5.05 },
  { label: "Info", aliases: "info|information|displayinfo|settings|setting|setup|option|options", x: 62.80, y: 36.95, w: 26.75, h: 5.05 },
  { label: "Exit", aliases: "exit|clear|cancel", x: 9.10, y: 45.45, w: 36.05, h: 4.95 },
  { label: "Menu", aliases: "menu|home", x: 53.95, y: 45.45, w: 35.70, h: 4.95 },
  { label: "Up", aliases: "up|directionup|arrowup|cursorup", x: 36.40, y: 49.85, w: 27.60, h: 6.30 },
  { label: "Left", aliases: "left|directionleft|arrowleft|cursorleft", x: 28.80, y: 54.70, w: 14.90, h: 12.10 },
  { label: "Right", aliases: "right|directionright|arrowright|cursorright", x: 56.30, y: 54.70, w: 14.90, h: 12.10 },
  { label: "Down", aliases: "down|directiondown|arrowdown|cursordown", x: 36.40, y: 64.55, w: 27.60, h: 6.20 },
  { label: "OK", aliases: "ok|select|enter", x: 40.10, y: 56.10, w: 19.80, h: 9.10 },
  { label: "Volume up", aliases: "volumeup|volup|vol up|vol_up|volume up", x: 9.30, y: 52.20, w: 19.30, h: 8.85 },
  { label: "Volume down", aliases: "volumedown|voldown|voldn|vol down|vol_down|vol_dn|volume down", x: 9.30, y: 61.05, w: 19.30, h: 9.05 },
  { label: "Channel up", aliases: "channelup|chup|chnext|ch_next|ch up|channel next|channelnext|pageup|pgup", x: 70.20, y: 52.20, w: 19.15, h: 8.85 },
  { label: "Channel down", aliases: "channeldown|chdown|chdn|chprev|ch_prev|ch down|ch_dn|channel prev|channel previous|channel down|channelprev|channeldn|pagedown|pgdown", x: 70.20, y: 61.05, w: 19.15, h: 9.05 },
  { label: "Mute", aliases: "mute", x: 9.30, y: 71.70, w: 36.20, h: 5.30 },
  { label: "Back", aliases: "back|return|previous", x: 54.15, y: 71.70, w: 35.55, h: 5.30 },
  { label: "1", aliases: "1|digit1|number1|num1", x: 9.30, y: 80.45, w: 27.10, h: 3.45 },
  { label: "2", aliases: "2|digit2|number2|num2", x: 36.40, y: 80.45, w: 26.25, h: 3.45 },
  { label: "3", aliases: "3|digit3|number3|num3", x: 62.60, y: 80.45, w: 27.05, h: 3.45 },
  { label: "4", aliases: "4|digit4|number4|num4", x: 9.30, y: 85.55, w: 27.10, h: 3.40 },
  { label: "5", aliases: "5|digit5|number5|num5", x: 36.40, y: 85.55, w: 26.25, h: 3.40 },
  { label: "6", aliases: "6|digit6|number6|num6", x: 62.60, y: 85.55, w: 27.05, h: 3.40 },
  { label: "7", aliases: "7|digit7|number7|num7", x: 9.30, y: 90.60, w: 27.10, h: 3.35 },
  { label: "8", aliases: "8|digit8|number8|num8", x: 36.40, y: 90.60, w: 26.25, h: 3.35 },
  { label: "9", aliases: "9|digit9|number9|num9", x: 62.60, y: 90.60, w: 27.05, h: 3.35 },
  { label: "Dash", aliases: "dash|hyphen|separator|dot|period|minus", x: 9.30, y: 95.70, w: 27.10, h: 3.35 },
  { label: "0", aliases: "0|digit0|number0|num0", x: 36.40, y: 95.70, w: 26.25, h: 3.35 },
  { label: "Enter", aliases: "enter|e", x: 62.60, y: 95.70, w: 27.05, h: 3.35 },
];

/* ir_command_key: lowercase, keep alphanumerics only. */
export function commandKey(name) {
  return String(name ?? "").toLowerCase().replace(/[^a-z0-9]/g, "");
}

/* ir_alias_match: exact key match, or the alias (when longer than 4 chars)
 * appears as a substring of the command key — same as the C strstr check. */
export function aliasMatch(cmdKey, aliases) {
  if (!cmdKey) return false;
  for (const raw of String(aliases ?? "").split("|")) {
    const key = commandKey(raw);
    if (!key) continue;
    if (key === cmdKey) return true;
    if (key.length > 4 && cmdKey.includes(key)) return true;
  }
  return false;
}

/* ir_find_remote_command: first device command whose name matches any alias. */
export function matchCommand(commands, aliases) {
  for (const command of commands ?? []) {
    if (aliasMatch(commandKey(command.name), aliases)) return command;
  }
  return null;
}

/* Tints for the A/B/C/D color row, keyed by label. */
export const KEY_TINTS = {
  Red: "tint-red",
  Green: "tint-green",
  Yellow: "tint-yellow",
  Blue: "tint-blue",
};

/* Canonical firmware ButtonKey names (as they appear in genuine MapList
   entries) for every hard key the setup wizard lets users map. Keys absent
   here are power or activity shortcuts, which activity maps do not carry. */
export const BUTTON_KEY_BY_LABEL = {
  Rewind: "Rewind",
  Play: "Play",
  Forward: "FastForward",
  Record: "Record",
  Pause: "Pause",
  Stop: "Stop",
  Red: "Red",
  Green: "Green",
  Yellow: "Yellow",
  Blue: "Blue",
  DVR: "Dvr",
  Guide: "Guide",
  Info: "Info",
  Exit: "Exit",
  Menu: "Menu",
  Up: "DirectionUp",
  Left: "DirectionLeft",
  Right: "DirectionRight",
  Down: "DirectionDown",
  OK: "Select",
  "Volume up": "VolumeUp",
  "Volume down": "VolumeDown",
  Mute: "VolumeMute",
  "Channel up": "ChannelUp",
  "Channel down": "ChannelDown",
  1: "Number1",
  2: "Number2",
  3: "Number3",
  4: "Number4",
  5: "Number5",
  6: "Number6",
  7: "Number7",
  8: "Number8",
  9: "Number9",
  0: "Number0",
};
/* Wizard graph builder: turns the guided-setup draft into genuine Harmony
   activity resources (Activity, ActivityButtonMap, ActivityFunctionMap) and
   saves the whole graph through /api/activity-save.
   Shapes mirror the vendored editor (payload/web/activity-ui.js) and the
   genuine Logitech fixture — same floors, same __type names, same fields. */

import * as api from "./api.js";

/* Highest identities Logitech ever issued for this hub; local allocation
   starts above them so it can never reuse a cloud-issued value. */
const MAP_ID_FLOOR = 52944089;
const BUTTON_ID_FLOOR = 1878029713;
const ID_CEILING = 2147483000;
const IDENTITY_KEYS = new Set(["Id", "Id-", "ButtonId", "ButtonMapId", "ButtonMapId-"]);

export const ACTIVITY_TYPES = [
  { value: 1, label: "Watch TV" },
  { value: 2, label: "Watch a movie" },
  { value: 3, label: "Play a game" },
  { value: 4, label: "Listen to music" },
];

export const ROLE_TYPES = [
  { type: "DisplayActivityRole", label: "Shows the picture", hint: "TV or projector — usually switches to an HDMI input" },
  { type: "VolumeActivityRole", label: "Controls the volume", hint: "Receiver, soundbar, or TV speakers" },
  { type: "PlayMovieActivityRole", label: "Plays movies & shows", hint: "Streamer, Blu-ray player, or media box" },
  { type: "PlayGameActivityRole", label: "Plays games", hint: "Console or gaming PC" },
  { type: "PlayMediaActivityRole", label: "Plays music & media", hint: "Music streamer or media player" },
  { type: "ChannelChangingActivityRole", label: "Changes channels", hint: "Cable box, tuner, or set-top box" },
  { type: "KeyboardTextEntryActivityRole", label: "Keyboard / typing", hint: "Device you type searches and logins into" },
];

export function roleLabel(type) {
  return ROLE_TYPES.find((r) => r.type === type)?.label ?? type;
}

export function createAllocator(config) {
  let nextMap = MAP_ID_FLOOR + 1;
  let nextId = BUTTON_ID_FLOOR + 1;
  const seen = new Set();
  const walk = (value) => {
    if (Array.isArray(value)) {
      value.forEach(walk);
      return;
    }
    if (value && typeof value === "object") {
      for (const [key, child] of Object.entries(value)) {
        if (IDENTITY_KEYS.has(key)) {
          const n = Number(child);
          if (Number.isFinite(n) && n > 0) {
            seen.add(n);
            if (key.startsWith("ButtonMapId")) nextMap = Math.max(nextMap, n + 1);
            else nextId = Math.max(nextId, n + 1);
          }
        } else {
          walk(child);
        }
      }
    }
  };
  walk(config);
  const take = (isMap) => {
    let cursor = isMap ? nextMap : nextId;
    while (seen.has(cursor) || cursor >= ID_CEILING) cursor += 1;
    seen.add(cursor);
    if (isMap) nextMap = cursor + 1;
    else nextId = cursor + 1;
    return cursor;
  };
  return { mapId: () => take(true), id: () => take(false) };
}

function harmonyDate() {
  return `/Date(${Date.now()}+0000)/`;
}

function commandAction(deviceId, command, eventType) {
  return {
    "DeviceId-": Number(deviceId),
    __type: "ButtonCommandAction",
    "FunctionId-": Number(command.functionId ?? 0),
    Order: 0,
    CommandName: String(command.name ?? command.command),
    EventType: eventType,
    Id: 0,
  };
}

function composeRoles(draft, alloc) {
  const orderByDevice = new Map();
  let nextOrder = 1;
  return draft.roles.map((role) => {
    if (!orderByDevice.has(role.deviceId)) {
      orderByDevice.set(role.deviceId, nextOrder);
      nextOrder += 1;
    }
    const order = orderByDevice.get(role.deviceId);
    return {
      "DeviceId-": Number(role.deviceId),
      SelectedInput: role.input
        ? { ChannelNumber: null, "Id-": alloc.id(), Name: role.input }
        : null,
      PowerOffOrder: order,
      __type: role.roleType,
      PowerOnOrder: order,
      NextDevicePowerOnDelay: role.powerDelay ? Number(role.powerDelay) : null,
      "Id-": alloc.id(),
    };
  });
}

function blankActivity(alloc) {
  const now = harmonyDate();
  return {
    "AccountId-": 0,
    Alternatives: [],
    BaseImageUri: null,
    DefaultChannel: null,
    DefaultStation: null,
    DefaultStationName: null,
    EnterActions: [],
    Icon: null,
    ImageKey: null,
    IsDefault: false,
    IsMultiZone: false,
    IsTuningDefault: false,
    LeaveActions: [],
    StartScreen: null,
    State: 0,
    SuggestedDisplay: null,
    Zones: [],
    "Id-": alloc.id(),
    Name: "New Activity",
    ActivityDisplayName: "New Activity",
    ActivityOrder: 0,
    ActivityGroup: 1,
    Type: 1,
    DateCreated: now,
    DateModified: now,
    Roles: [],
  };
}

function surfaceTemplate(config) {
  const maps = config?.mapList?.ButtonMaps ?? [];
  const surface = maps.find((m) =>
    m?.__type === "ActivityButtonMap" && /^16414Activity/.test(String(m?.ButtonMapIdentifier ?? "")));
  const fallback = maps.find((m) => m?.__type === "ActivityButtonMap");
  const source = surface ?? fallback ?? {};
  return {
    "ButtonMapSurfaceId-": source["ButtonMapSurfaceId-"] ?? null,
    "RemoteId-": source["RemoteId-"] ?? null,
    "SurfaceId-": source["SurfaceId-"] ?? null,
  };
}

function composeButtonMap(draft, activityId, config, alloc) {
  const buttons = [];
  for (const [buttonKey, mapping] of Object.entries(draft.buttons)) {
    if (!mapping?.command) continue;
    buttons.push({
      ButtonId: alloc.id(),
      __type: "HardRemoteButton",
      ButtonAction: commandAction(mapping.deviceId, mapping.command, 1),
      ButtonDoublePressAction: null,
      FunctionGroupType: /^Number\d$/.test(buttonKey) ? 2 : 0,
      ButtonState: 1,
      ButtonKey: buttonKey,
      ButtonLongPressAction: mapping.hold?.command
        ? commandAction(mapping.hold.deviceId, mapping.hold.command, 2)
        : null,
    });
  }
  return {
    "ButtonMapId-": alloc.mapId(),
    "ActivityId-": Number(activityId),
    Buttons: buttons,
    ...surfaceTemplate(config),
    __type: "ActivityButtonMap",
    ButtonMapIdentifier: `16414Activity${activityId}`,
    DateModified: harmonyDate(),
    Sequences: [],
  };
}

function composeFunctionMap(activityId) {
  return {
    UIModeName: `Functions.UserConfigurator.${activityId}`,
    __type: "ActivityFunctionMap",
    "ActivityId-": Number(activityId),
    FunctionGroups: [],
  };
}

/* Build the three replacement resources for the draft and POST them.
   editId: when set, that activity (and its maps) is replaced in place;
   otherwise a new activity is appended at the end of the order. */
export async function saveDraft({ config, revision, draft, editId }) {
  const alloc = createAllocator(config);

  const activities = structuredClone(config.activityList?.Activities ?? []);
  const buttonMaps = structuredClone(config.mapList?.ButtonMaps ?? []);
  const functionMaps = (config.functionList?.FunctionMaps ?? []).map((m) => structuredClone(m));

  let activity;
  if (editId) {
    const index = activities.findIndex((a) => String(a["Id-"]) === String(editId));
    if (index === -1) throw new Error("The activity being edited no longer exists in this config.");
    activity = activities[index];
  } else {
    activity = blankActivity(alloc);
    activity.ActivityOrder = activities.length;
    activities.push(activity);
  }

  activity.Name = draft.name.trim();
  activity.ActivityDisplayName = activity.Name;
  activity.Type = Number(draft.type);
  activity.DateModified = harmonyDate();
  activity.Roles = composeRoles(draft, alloc);

  const activityId = activity["Id-"];
  const map = composeButtonMap(draft, activityId, config, alloc);
  const functionMap = composeFunctionMap(activityId);

  const keptMaps = buttonMaps.filter((m) => String(m?.["ActivityId-"]) !== String(activityId));
  keptMaps.push(map);
  const keptFunctions = functionMaps.filter((m) =>
    !(String(m?.__type ?? "").includes("ActivityFunctionMap") && String(m?.["ActivityId-"]) === String(activityId)));
  keptFunctions.push(functionMap);

  const payload = {
    baseRevision: revision,
    activityList: { Activities: activities },
    mapList: { ButtonMaps: keptMaps },
    functionList: { FunctionMaps: keptFunctions },
  };
  const result = await api.saveActivity(payload);
  return { result, activityId: String(activityId), name: activity.Name };
}

export async function deleteActivityGraph({ config, revision, id }) {
  const activities = (config.activityList?.Activities ?? []).filter(
    (a) => String(a["Id-"]) !== String(id));
  const keptMaps = (config.mapList?.ButtonMaps ?? []).filter(
    (m) => String(m?.["ActivityId-"]) !== String(id));
  const keptFunctions = (config.functionList?.FunctionMaps ?? []).filter((m) =>
    !(String(m?.__type ?? "").includes("ActivityFunctionMap") && String(m?.["ActivityId-"]) === String(id)));
  const result = await api.saveActivity({
    baseRevision: revision,
    activityList: { Activities: activities },
    mapList: { ButtonMaps: keptMaps },
    functionList: { FunctionMaps: keptFunctions },
  });
  return { result };
}

export async function reorderActivityGraph({ config, revision, id, direction }) {
  const activities = structuredClone(config.activityList?.Activities ?? []);
  const ordered = [...activities].sort((a, b) => (a.ActivityOrder ?? 0) - (b.ActivityOrder ?? 0));
  const index = ordered.findIndex((a) => String(a["Id-"]) === String(id));
  const target = index + Number(direction);
  if (index < 0 || target < 0 || target >= ordered.length) return { result: null, moved: false };
  [ordered[index], ordered[target]] = [ordered[target], ordered[index]];
  ordered.forEach((a, i) => { a.ActivityOrder = i; });
  const result = await api.saveActivity({
    baseRevision: revision,
    activityList: { Activities: activities },
    mapList: structuredClone(config.mapList ?? { ButtonMaps: [] }),
    functionList: structuredClone(config.functionList ?? { FunctionMaps: [] }),
  });
  return { result, moved: true };
}
/* Placeholder views for setup pages that require the live hub.
 * The sim serves fixtures only; these panels say so plainly. */

export function createPlaceholderView(section, { title, lead, body, foot, icon }) {
  section.innerHTML = `
    <div class="view-head">
      <div>
        <h2>${title}</h2>
        <p class="view-lead">${lead}</p>
      </div>
    </div>
    <section class="panel placeholder" aria-label="${title}">
      <div class="placeholder-icon">${icon}</div>
      <p class="notice notice-info">Sim: setup pages use the live hub.</p>
      <p class="placeholder-body">${body}</p>
      <p class="placeholder-foot mono">${foot}</p>
    </section>`;

  return {
    onShow() {},
    onHide() {},
  };
}

/* Copy for each placeholder route, keyed by route name. */
export const PLACEHOLDER_PAGES = {
  ir: {
    title: "IR setup",
    lead: "Create and edit IR devices, search code databases, and learn buttons.",
    body: "The sim has no IR hardware or code database, so this page is inert here. On the hub it manages devices, learned codes, and command timing — the same devices that feed the Control remote.",
    foot: "served by codex_webui · GET /ir",
  },
  bluetooth: {
    title: "Bluetooth",
    lead: "Pair Bluetooth keyboards and HID bridges.",
    body: "Pairing needs the hub radio and a device in range. In the sim this page stays read-only; on the hub it lists paired HID devices and lets you add or remove them.",
    foot: "served by codex_webui · GET /bluetooth",
  },
  mqtt: {
    title: "MQTT",
    lead: "Connect a broker and publish hub state to Home Assistant.",
    body: "Broker connections are opened by the hub itself, so the sim does not socket out. On the hub this page configures the broker address, topics, discovery prefix, and state publishing interval.",
    foot: "served by codex_webui · GET /mqtt",
  },
  wifi: {
    title: "Wi-Fi",
    lead: "Join, forget, and inspect wireless networks.",
    body: "Wireless configuration lives on the hub hardware. The sim has no wlan interface to scan, so there is nothing to list here — on the hub this page shows nearby networks and connection status.",
    foot: "served by codex_webui · GET /wifi",
  },
  backup: {
    title: "Backup",
    lead: "Download a restore point before making larger changes.",
    body: "Backups package the hub's real configuration — ActivityList, MapList, FunctionList, and device IR data. The sim serves static fixtures, so there is nothing to download here.",
    foot: "served by codex_webui · GET /backup",
  },
  system: {
    title: "System",
    lead: "Firmware, logs, reboot, and LAN-only egress.",
    body: "System controls act on hub hardware. In the sim these controls are display-only; on the hub this page shows firmware version, uptime, logs, and the cloud-egress switch.",
    foot: "served by codex_webui · GET /system",
  },
};
/* Home view: what is on, one-tap start, sim status, recent sim events. */

import * as api from "../api.js";
import * as hub from "../state.js";

const TEMPLATE = `
  <div class="view-head">
    <div>
      <h2 id="title-home">Home</h2>
      <p class="view-lead">The rack at a glance — what is running, what can start, and what the sim has been doing.</p>
    </div>
    <div class="view-actions">
      <a class="btn btn-secondary" href="#control">Open remote</a>
    </div>
  </div>
  <section class="now-strip" id="nowStrip" aria-label="Now running">
    <div class="now-main">
      <span class="eyebrow" id="nowEyebrow">Now running</span>
      <h3 class="now-name" id="nowName">Reading hub state…</h3>
      <p class="now-meta mono" id="nowMeta"></p>
    </div>
    <div class="now-actions">
      <button type="button" class="btn btn-ghost" data-act="refresh">Refresh state</button>
      <button type="button" class="btn btn-danger" data-act="poweroff" id="nowPowerOff" disabled>Power off</button>
    </div>
  </section>
  <div class="dash-grid">
    <div class="dash-left">
      <section class="panel" aria-label="Activities">
        <div class="panel-head"><h3>Start an activity</h3><span class="mono muted" id="dashCount"></span></div>
        <div id="dashTiles" class="tile-grid stagger"></div>
      </section>
    </div>
    <div class="dash-right">
      <section class="panel" aria-label="Recent sim events">
        <div class="panel-head"><h3>Recent sim events</h3><button type="button" class="btn btn-quiet btn-sm" data-act="events">Refresh</button></div>
        <ol id="dashEvents" class="event-log"></ol>
      </section>
    </div>
  </div>
  <p class="sim-line mono" id="simLine"></p>`;

function eventTypeClass(kind) {
  const k = String(kind ?? "").toLowerCase();
  if (k.includes("run") || k.includes("start") || k.includes("state") || k.includes("reset")) {
    return "is-state";
  }
  if (k.includes("error") || k.includes("warn") || k.includes("reject")) return "is-error";
  return "";
}

function eventBadge(kind) {
  const k = String(kind ?? "").toLowerCase();
  if (k.includes("start") || k.includes("run")) return "run";
  if (k.includes("hold") || k.includes("button") || k.includes("ir")) return "key";
  if (k.includes("reset")) return "rst";
  if (k.includes("reject")) return "err";
  return (k || "sim").slice(0, 8);
}

function eventMessage(ev) {
  const k = String(ev?.kind ?? "").toLowerCase();
  if (k.includes("startactivity") || k.includes("run")) {
    if (ev.activityId === "-1") return "Start · Everything off";
    const name = hub.activityName(hub.activityById(ev.activityId));
    const rejected = k.includes("reject") ? " (rejected)" : "";
    return `Start · ${name}${rejected}`;
  }
  if (k.includes("hold") || k.includes("button")) {
    const held = ev.pressType && ev.pressType !== "press" ? ` (${ev.pressType})` : "";
    const status = ev.status && !ev.pressType ? ` · ${ev.status}` : "";
    return `${ev.buttonKey ?? ev.command ?? "Key"}${held}${status} → ${hub.deviceName(ev.deviceId)} · ${ev.command ?? "?"}`;
  }
  if (k.includes("reset")) return "Engine reset";
  return ev.message ?? ev.kind ?? "sim event";
}

export function createDashboardView(section) {
  let mounted = false;
  let els;

  function mount() {
    if (mounted) return;
    mounted = true;
    section.innerHTML = TEMPLATE;
    els = {
      strip: section.querySelector("#nowStrip"),
      eyebrow: section.querySelector("#nowEyebrow"),
      name: section.querySelector("#nowName"),
      meta: section.querySelector("#nowMeta"),
      powerOff: section.querySelector("#nowPowerOff"),
      count: section.querySelector("#dashCount"),
      tiles: section.querySelector("#dashTiles"),
      simLine: section.querySelector("#simLine"),
      events: section.querySelector("#dashEvents"),
    };

    section.addEventListener("click", (e) => {
      const act = e.target.closest("[data-act]")?.dataset.act;
      if (act === "refresh") hub.refreshState();
      else if (act === "events") loadEvents();
      else if (act === "poweroff") hub.setRunning(-1);
      const run = e.target.closest("[data-run]");
      if (run) hub.setRunning(run.dataset.run);
      const retry = e.target.closest("[data-retry]");
      if (retry) hub.reloadConfig();
    });

    hub.subscribe(renderHub);
    renderHub();
  }

  function renderHub() {
    const s = hub.state;
    renderNow(s);
    renderTiles(s);
    renderSimLine(s);
  }

  function renderNow(s) {
    const running = s.currentId && s.currentId !== "-1";
    const activity = running ? hub.activityById(s.currentId) : null;
    els.strip.classList.toggle("is-off", !running);
    if (running) {
      els.eyebrow.textContent = "Now running";
      els.name.textContent = activity ? hub.activityName(activity) : `Activity ${s.currentId}`;
      els.meta.textContent = activity
        ? `${hub.activityTypeLabel(activity)} · activity ${s.currentId}`
        : `activity ${s.currentId}`;
      els.powerOff.disabled = false;
    } else if (s.currentId === "-1") {
      els.eyebrow.textContent = "Now running";
      els.name.textContent = "Everything is off";
      els.meta.textContent = "PowerOff is active";
      els.powerOff.disabled = true;
    } else {
      els.eyebrow.textContent = "Now running";
      els.name.textContent = "Nothing running yet";
      els.meta.textContent = s.stateError
        ? `Hub state unavailable: ${s.stateError.message}`
        : "Start an activity below or open the remote";
      els.powerOff.disabled = true;
    }
  }

  function renderTiles(s) {
    if (!s.configLoaded) {
      els.count.textContent = "";
      els.tiles.innerHTML = `<div class="state-block" style="grid-column:1/-1"><div class="skel" style="width:70%"></div><div class="skel"></div></div>`;
      return;
    }
    if (s.configError) {
      els.count.textContent = "";
      els.tiles.innerHTML = `<div class="state-block" style="grid-column:1/-1">
        <span class="state-title">Could not load hub config</span>
        ${s.configError.message}
        <div style="margin-top:var(--space-3)"><button type="button" class="btn btn-secondary btn-sm" data-retry>Retry</button></div>
      </div>`;
      return;
    }
    const acts = hub.activities();
    els.count.textContent = `${acts.length} activities`;
    if (!acts.length) {
      els.tiles.innerHTML = `<div class="state-block" style="grid-column:1/-1">No activities in this hub config. Add some in the Activities editor.</div>`;
      return;
    }
    els.tiles.innerHTML = acts
      .map((a, i) => {
        const id = String(a["Id-"]);
        const live = s.currentId === id;
        return `<div class="tile${live ? " is-live" : ""}" style="--i:${i}">
          <span class="tile-main">
            <span class="tile-name">${hub.activityName(a)}</span>
            <span class="tile-meta mono">${hub.activityTypeLabel(a)} · id ${id}</span>
          </span>
          ${
            live
              ? `<span class="pill pill-live"><span class="live-dot" aria-hidden="true"></span>On air</span>`
              : `<button type="button" class="btn btn-quiet btn-sm" data-run="${id}">Start</button>`
          }
        </div>`;
      })
      .join("");
  }

  function renderSimLine(s) {
    if (!s.configLoaded || s.configError) {
      els.simLine.textContent = "sim · config unavailable";
      return;
    }
    const c = hub.counts();
    els.simLine.textContent = `sim · ${c.activities} activities · ${c.devices} devices · ${c.buttonMaps} button maps · rev ${c.revision}`;
  }

  function eventsPanel() {
    return section.querySelector('[aria-label="Recent sim events"]');
  }

  async function loadEvents() {
    const panel = eventsPanel();
    els.events.innerHTML = `<li><span class="ev-time mono">--:--:--</span><span class="ev-type">sim</span><span class="ev-msg">Loading events…</span></li>`;
    try {
      const [, payload] = await Promise.all([hub.ensureConfig(), api.getSimEvents()]);
      if (panel) panel.hidden = false;
      const events = payload?.events ?? [];
      if (!events.length) {
        els.events.innerHTML = `<li><span class="ev-time mono"></span><span class="ev-type">sim</span><span class="ev-msg">No events yet — press some keys in Control.</span></li>`;
        return;
      }
      els.events.innerHTML = events
        .slice()
        .reverse()
        .map((ev) => {
          const time = ev.ts
            ? new Date(ev.ts).toLocaleTimeString([], { hour12: false })
            : "--:--:--";
          return `<li>
            <span class="ev-time mono">${time}</span>
            <span class="ev-type ${eventTypeClass(ev.kind)}">${eventBadge(ev.kind)}</span>
            <span class="ev-msg">${eventMessage(ev)}</span>
          </li>`;
        })
        .join("");
    } catch (_) {
      if (panel) panel.hidden = true;
    }
  }

  mount();

  return {
    onShow() {
      renderHub();
      loadEvents();
    },
    onHide() {},
  };
}
import * as api from "../api.js";
import * as hub from "../state.js";
import {
  REMOTE_BUTTONS,
  aliasMatch,
  commandKey,
  matchCommand,
} from "../remote-layout.js";

const HOLD_MS = 550;
const LOG_MAX = 14;
const SOFT_MAX = 24;

const TEMPLATE = `
  <div class="view-head">
    <div>
      <h2 id="title-control">Control</h2>
      <p class="view-lead">One handset for the whole rack. Pick a source, press keys — the resolved device and command always show before you send.</p>
    </div>
    <div class="view-actions">
      <div class="segmented" role="group" aria-label="Control mode">
        <button type="button" data-mode="activities" aria-pressed="true">Activities</button>
        <button type="button" data-mode="devices" aria-pressed="false">Devices</button>
      </div>
      <button type="button" class="btn btn-danger" data-act="poweroff" id="ctrlPowerOff" disabled>Power off</button>
    </div>
  </div>
  <section class="now-strip" id="ctrlNowStrip" aria-label="Now running">
    <div class="now-main">
      <span class="eyebrow" id="ctrlNowEyebrow">Now running</span>
      <h3 class="now-name" id="ctrlNowName">Reading hub state…</h3>
      <p class="now-meta mono" id="ctrlNowMeta"></p>
    </div>
  </section>
  <p class="remote-status" id="remoteStatus" role="status" aria-live="polite">
    <span id="statusTarget" class="status-target">Pick a key</span>
    <span id="statusNote" class="status-note">resolved device and command show here</span>
  </p>
  <div class="control-grid">
    <aside class="panel control-src" aria-label="Source list">
      <div class="panel-head"><h3 id="srcTitle">Activities</h3><span class="mono muted" id="srcMeta"></span></div>
      <div id="srcList" class="src-list"></div>
    </aside>
    <div class="control-remotecol">
      <div class="remote-wrap">
        <div class="ir-remote-card">
          <div class="ir-remote-shell">
            <div class="ir-remote-skin" id="remoteBody" role="group" aria-label="Harmony remote">
              <img src="/assets/remote-skin.jpg" alt="Harmony remote control layout" width="591" height="1280" draggable="false">
            </div>
          </div>
          <p class="remote-help muted">Same skin and button map as the hub IR Control page. Hover or tap a key to see what it sends; unmapped keys stay quiet.</p>
        </div>
        <div class="chip-grid" id="softChips" aria-label="Soft menu buttons not on the hard remote"></div>
      </div>
    </div>
    <div class="control-side">
      <details class="panel inspector" id="inspector">
        <summary>
          <span class="inspector-title">Inspector</span>
          <span class="mono muted" id="resolveMeta"></span>
        </summary>
        <div class="inspector-body">
          <div class="inspector-actions">
            <button type="button" class="btn btn-quiet btn-sm" data-act="refresh">Refresh state</button>
            <button type="button" class="btn btn-quiet btn-sm" data-act="clearlog">Clear log</button>
          </div>
          <h4 class="inspector-h">Resolved actions</h4>
          <div id="resolveList" class="resolve-list"></div>
          <h4 class="inspector-h">Send log</h4>
          <ol id="sendLog" class="send-log"><li class="send-hint">Press a key — sends appear here.</li></ol>
        </div>
      </details>
    </div>
  </div>`;

export function createControlView(section) {
  let mode = "activities";
  let selectedActivityId = "";
  let selectedDeviceId = "";
  let resolutions = []; // index -> action | null
  let softButtons = []; // { label, action }
  let lastStatus = null;
  let mounted = false;
  let els;

  /* -- long-press bookkeeping ------------------------------------ */
  let holdTimer = null;
  let holdFired = false;
  let suppressClick = false;

  function mount() {
    if (mounted) return;
    mounted = true;
    section.innerHTML = TEMPLATE;
    els = {
      powerOff: section.querySelector("#ctrlPowerOff"),
      nowStrip: section.querySelector("#ctrlNowStrip"),
      nowEyebrow: section.querySelector("#ctrlNowEyebrow"),
      nowName: section.querySelector("#ctrlNowName"),
      nowMeta: section.querySelector("#ctrlNowMeta"),
      srcTitle: section.querySelector("#srcTitle"),
      srcMeta: section.querySelector("#srcMeta"),
      srcList: section.querySelector("#srcList"),
      body: section.querySelector("#remoteBody"),
      chips: section.querySelector("#softChips"),
      statusTarget: section.querySelector("#statusTarget"),
      statusNote: section.querySelector("#statusNote"),
      resolveList: section.querySelector("#resolveList"),
      resolveMeta: section.querySelector("#resolveMeta"),
      log: section.querySelector("#sendLog"),
      segmented: section.querySelector(".segmented"),
      inspector: section.querySelector("#inspector"),
    };
    if (localStorage.getItem("hhc.inspector") === "open") els.inspector.open = true;
    els.inspector.addEventListener("toggle", () => {
      localStorage.setItem("hhc.inspector", els.inspector.open ? "open" : "closed");
    });
    buildKeys();
    wire();
    hub.subscribe(renderAll);
    renderAll();
  }

  function buildKeys() {
    const frag = document.createDocumentFragment();
    REMOTE_BUTTONS.forEach((b, i) => {
      const el = document.createElement("button");
      el.type = "button";
      el.className = "remote-hotspot disabled";
      el.dataset.index = String(i);
      el.style.left = `${b.x}%`;
      el.style.top = `${b.y}%`;
      el.style.width = `${b.w}%`;
      el.style.height = `${b.h}%`;
      el.disabled = true;
      el.setAttribute("aria-label", `${b.label} — not mapped`);
      el.title = b.label;
      frag.appendChild(el);
    });
    els.body.appendChild(frag);
  }

  function wire() {
    els.segmented.addEventListener("click", (e) => {
      const btn = e.target.closest("[data-mode]");
      if (btn) setMode(btn.dataset.mode);
    });

    section.addEventListener("click", (e) => {
      const act = e.target.closest("[data-act]")?.dataset.act;
      if (act === "refresh") refresh();
      else if (act === "poweroff") powerOff();
      else if (act === "clearlog") els.log.innerHTML = "";
      const run = e.target.closest("[data-run]");
      if (run) {
        if (mode === "activities") {
          selectedActivityId = run.dataset.run;
          applyMapping();
          renderSrcList();
        }
        runActivity(run.dataset.run);
      }
      const select = e.target.closest("[data-select]");
      if (select) {
        if (mode === "activities") selectedActivityId = select.dataset.select;
        else selectedDeviceId = select.dataset.select;
        applyMapping();
        renderSrcList();
      }
      const soft = e.target.closest("[data-soft]");
      if (soft) {
        const entry = softButtons[Number(soft.dataset.soft)];
        if (entry) sendAction(entry.action, entry.label, soft);
      }
      const resolve = e.target.closest("[data-resolve]");
      if (resolve && !resolve.disabled) {
        const r = resolutions[Number(resolve.dataset.resolve)];
        if (r) sendAction(r, REMOTE_BUTTONS[Number(resolve.dataset.resolve)].label);
      }
      const command = e.target.closest("[data-command]");
      if (command) {
        const device = hub.deviceById(selectedDeviceId);
        const cmd = device?.commands[Number(command.dataset.command)];
        if (cmd) sendAction({ deviceId: device.id, command: cmd.name, functionId: cmd.functionId }, cmd.name);
      }
      const retry = e.target.closest("[data-retry]");
      if (retry) hub.reloadConfig();
    });

    els.body.addEventListener("pointerdown", (e) => {
      const el = e.target.closest(".remote-hotspot");
      if (!el || el.disabled) return;
      const r = resolutions[Number(el.dataset.index)];
      if (!r) return;
      suppressClick = true;
      holdFired = false;
      if (r.hold) {
        el.setPointerCapture?.(e.pointerId);
        holdTimer = setTimeout(() => {
          holdFired = true;
          el.classList.add("is-holding");
          sendAction(r.hold, `${REMOTE_BUTTONS[Number(el.dataset.index)].label} (held)`, el);
        }, HOLD_MS);
      }
    });

    const release = () => {
      clearTimeout(holdTimer);
      holdTimer = null;
      els.body.querySelectorAll(".remote-hotspot.is-holding").forEach((k) => k.classList.remove("is-holding"));
    };
    els.body.addEventListener("pointerup", (e) => {
      const el = e.target.closest(".remote-hotspot");
      release();
      if (!el || el.disabled || holdFired) return;
      const r = resolutions[Number(el.dataset.index)];
      if (r) sendAction(r, REMOTE_BUTTONS[Number(el.dataset.index)].label, el);
    });
    els.body.addEventListener("pointercancel", release);
    els.body.addEventListener("pointerleave", () => {
      if (holdTimer) release();
    });

    els.body.addEventListener("click", (e) => {
      if (suppressClick) {
        suppressClick = false;
        return;
      }
      const el = e.target.closest(".remote-hotspot");
      if (!el || el.disabled) return;
      const r = resolutions[Number(el.dataset.index)];
      if (r) sendAction(r, REMOTE_BUTTONS[Number(el.dataset.index)].label, el);
    });

    const preview = (el) => {
      const r = el && resolutions[Number(el.dataset.index)];
      if (!r) return;
      setStatus(`${hub.deviceName(r.deviceId)} · ${r.command}`, "will send", "");
    };
    els.body.addEventListener("pointerover", (e) => preview(e.target.closest(".remote-hotspot")));
    els.body.addEventListener("focusin", (e) => preview(e.target.closest(".remote-hotspot")));
    const restore = () => {
      if (lastStatus) setStatus(lastStatus.target, lastStatus.note, lastStatus.cls);
      else setStatus("Pick a key", "resolved device and command show here", "");
    };
    els.body.addEventListener("pointerout", (e) => {
      if (!els.body.contains(e.relatedTarget)) restore();
    });
    els.body.addEventListener("focusout", (e) => {
      if (!els.body.contains(e.relatedTarget)) restore();
    });
  }

  /* -- mapping ------------------------------------------------------ */

  function primaryMap(activityId) {
    let best = null;
    let bestCount = -1;
    for (const map of hub.buttonMapsForActivity(activityId)) {
      const count = (map.Buttons ?? []).filter((b) => b.ButtonKey).length;
      if (count > bestCount) {
        best = map;
        bestCount = count;
      }
    }
    return best;
  }

  function actionFromEntry(entry) {
    const a = entry.ButtonAction;
    if (!a?.CommandName) return null;
    return {
      deviceId: String(a["DeviceId-"]),
      command: a.CommandName,
      functionId: a["FunctionId-"],
      buttonKey: entry.ButtonKey ?? null,
    };
  }

  function applyMapping() {
    resolutions = REMOTE_BUTTONS.map(() => null);
    softButtons = [];

    if (mode === "activities") {
      const map = primaryMap(selectedActivityId);
      const seen = new Set();
      for (const entry of map?.Buttons ?? []) {
        const action = actionFromEntry(entry);
        if (!action) continue;
        if (entry.ButtonKey) {
          const index = REMOTE_BUTTONS.findIndex((b) =>
            aliasMatch(commandKey(entry.ButtonKey), b.aliases));
          if (index !== -1 && !resolutions[index]) {
            const holdEntry = entry.ButtonLongPressAction?.CommandName
              ? {
                  deviceId: String(entry.ButtonLongPressAction["DeviceId-"]),
                  command: entry.ButtonLongPressAction.CommandName,
                  functionId: entry.ButtonLongPressAction["FunctionId-"],
                  buttonKey: entry.ButtonKey,
                }
              : null;
            resolutions[index] = { ...action, hold: holdEntry };
          }
        } else {
          const key = `${action.deviceId}:${action.command}`;
          if (!seen.has(key) && softButtons.length < SOFT_MAX) {
            seen.add(key);
            softButtons.push({ label: entry.TextOnRemote || action.command, action });
          }
        }
      }
    } else {
      const device = hub.deviceById(selectedDeviceId);
      REMOTE_BUTTONS.forEach((b, i) => {
        const cmd = matchCommand(device?.commands, b.aliases);
        if (cmd) {
          resolutions[i] = {
            deviceId: device.id,
            command: cmd.name,
            functionId: cmd.functionId,
            buttonKey: null,
            hold: null,
          };
        }
      });
    }
    renderKeys();
    renderChips();
    renderResolve();
  }

  function renderKeys() {
    els.body.querySelectorAll(".remote-hotspot").forEach((el) => {
      const i = Number(el.dataset.index);
      const b = REMOTE_BUTTONS[i];
      const r = resolutions[i];
      if (r) {
        el.disabled = false;
        el.classList.remove("disabled");
        el.classList.toggle("has-hold", Boolean(r.hold));
        el.title = `${b.label} → ${hub.deviceName(r.deviceId)} · ${r.command}`;
        el.setAttribute(
          "aria-label",
          `${b.label} — ${hub.deviceName(r.deviceId)} ${r.command}` +
            (r.hold ? ` (hold: ${r.hold.command})` : ""));
      } else {
        el.disabled = true;
        el.classList.add("disabled");
        el.classList.remove("has-hold");
        el.title = `${b.label} (not mapped)`;
        el.setAttribute("aria-label", `${b.label} — not mapped`);
      }
    });
  }

  function renderChips() {
    els.chips.innerHTML = softButtons
      .map(
        (s, i) =>
          `<button type="button" class="chip" data-soft="${i}" title="${hub.deviceName(s.action.deviceId)} · ${s.action.command}">${s.label}</button>`)
      .join("");
  }

  function renderResolve() {
    if (mode === "devices") {
      const device = hub.deviceById(selectedDeviceId);
      els.resolveMeta.textContent = device ? `${device.commands.length} commands` : "";
      if (!device?.commands.length) {
        els.resolveList.innerHTML = `<div class="resolve-empty">No commands for this device.</div>`;
        return;
      }
      els.resolveList.innerHTML = device.commands
        .map((cmd, i) => {
          const keyIndex = REMOTE_BUTTONS.findIndex((b) =>
            aliasMatch(commandKey(cmd.name), b.aliases));
          const target = keyIndex !== -1 ? `on remote: ${REMOTE_BUTTONS[keyIndex].label}` : "not on remote";
          return `<button type="button" class="resolve-row" data-command="${i}">
            <span class="resolve-key">${cmd.name}</span>
            <span class="resolve-target">${target} · send direct</span>
          </button>`;
        })
        .join("");
      return;
    }

    const mapped = resolutions
      .map((r, i) => ({ r, i }))
      .filter(({ r }) => r);
    els.resolveMeta.textContent = `${mapped.length}/${REMOTE_BUTTONS.length} mapped`;
    if (!mapped.length) {
      els.resolveList.innerHTML = `<div class="resolve-empty">No buttons mapped for this activity yet. Map keys in the <a href="#activities">Activities editor</a>.</div>`;
      return;
    }
    els.resolveList.innerHTML = mapped
      .map(({ r, i }) =>
        `<button type="button" class="resolve-row" data-resolve="${i}" title="Send now">
          <span class="resolve-key">${REMOTE_BUTTONS[i].label}</span>
          <span class="resolve-target">${hub.deviceName(r.deviceId)} · ${r.command}${r.hold ? ` · hold: ${r.hold.command}` : ""}</span>
        </button>`)
      .join("");
  }

  /* -- source list ----------------------------------------------------- */

  function renderSrcList() {
    els.srcTitle.textContent = mode === "activities" ? "Activities" : "Devices";
    const s = hub.state;

    if (!s.configLoaded) {
      els.srcMeta.textContent = "";
      els.srcList.innerHTML = `<div class="state-block"><div class="skel" style="width:80%"></div><div class="skel"></div><div class="skel" style="width:65%"></div></div>`;
      return;
    }
    if (s.configError) {
      els.srcMeta.textContent = "";
      els.srcList.innerHTML = `<div class="state-block">
        <span class="state-title">Could not load hub config</span>
        ${s.configError.message}
        <div style="margin-top:var(--space-3)"><button type="button" class="btn btn-secondary btn-sm" data-retry>Retry</button></div>
      </div>`;
      return;
    }

    if (mode === "activities") {
      const acts = hub.activities();
      els.srcMeta.textContent = `${acts.length} in ActivityList`;
      if (!acts.length) {
        els.srcList.innerHTML = `<div class="state-block">No activities in this hub config.</div>`;
        return;
      }
      els.srcList.innerHTML = acts
        .map((a) => {
          const id = String(a["Id-"]);
          const live = s.currentId === id;
          const selected = selectedActivityId === id;
          return `<div class="src-row${selected ? " is-selected" : ""}${live ? " is-live" : ""}">
            <span class="src-order mono">${String(a.ActivityOrder ?? 0).padStart(2, "0")}</span>
            <button type="button" class="src-main" data-select="${id}" title="${hub.activityName(a)} · ${hub.activityTypeLabel(a)} · ${id}">
              <span class="src-name">${hub.activityName(a)}</span>
              <span class="src-meta mono">${hub.activityTypeLabel(a)} · ${id}</span>
            </button>
            <span class="src-side">${
              live
                ? `<span class="pill pill-live"><span class="live-dot" aria-hidden="true"></span>On air</span>`
                : `<button type="button" class="btn btn-quiet btn-sm" data-run="${id}">Run</button>`
            }</span>
          </div>`;
        })
        .join("");
      return;
    }

    const devs = hub.devices();
    els.srcMeta.textContent = `${devs.length} devices`;
    if (!devs.length) {
      els.srcList.innerHTML = `<div class="state-block">No devices in this hub config.</div>`;
      return;
    }
    els.srcList.innerHTML = devs
      .map((d) =>
        `<button type="button" class="src-row${selectedDeviceId === d.id ? " is-selected" : ""}" data-select="${d.id}" aria-pressed="${selectedDeviceId === d.id}">
          <span class="src-order mono">${d.commands.length}</span>
          <span class="src-main">
            <span class="src-name">${d.name}</span>
            <span class="src-meta mono">${d.manufacturer || "Unknown"} · ${d.commands.length} commands</span>
          </span>
        </button>`)
      .join("");
  }

  /* -- status + log ------------------------------------------------------ */

  function setStatus(target, note, cls) {
    els.statusTarget.textContent = target;
    els.statusNote.textContent = note;
    els.statusNote.className = `status-note${cls ? ` ${cls}` : ""}`;
    if (cls !== "") lastStatus = { target, note, cls };
  }

  function addLog(target, note, cls) {
    els.log.querySelector(".send-hint")?.remove();
    const li = document.createElement("li");
    const time = new Date().toLocaleTimeString([], { hour12: false });
    li.innerHTML = `<span class="send-time mono">${time}</span>
      <span class="send-target">${target}</span>
      <span class="send-note ${cls}">${note}</span>`;
    els.log.prepend(li);
    while (els.log.children.length > LOG_MAX) els.log.lastChild.remove();
  }

  function flash(el) {
    if (!el) return;
    el.classList.add("is-sending");
    setTimeout(() => el.classList.remove("is-sending"), 220);
  }

  /* -- sending -------------------------------------------------------------- */

  async function sendAction(action, label, el) {
    const target = `${hub.deviceName(action.deviceId)} · ${action.command}`;
    flash(el);
    setStatus(target, "sending…", "");
    const { note, cls } = await directIr(action, "sent");
    setStatus(`${label} → ${target}`, note, cls);
    addLog(target, note, cls);
  }

  async function directIr(action, okNote) {
    try {
      await api.irSend({
        deviceId: action.deviceId,
        command: action.command,
        functionId: action.functionId,
        activityId: mode === "activities" ? selectedActivityId : undefined,
      });
      return { note: okNote, cls: "is-ok" };
    } catch (error) {
      if (error instanceof api.ApiError && error.status > 0) {
        return { note: error.message || `HTTP ${error.status}`, cls: "is-err" };
      }
      const message =
        error instanceof api.ApiError
          ? error.message
          : error?.message || "network error";
      return { note: message, cls: "is-local" };
    }
  }

  async function runActivity(id) {
    const name = hub.activityName(hub.activityById(id));
    setStatus(name, "starting…", "");
    await hub.setRunning(id);
    if (hub.state.stateError) {
      const msg = hub.state.stateError.message || "run failed";
      setStatus(name, msg, "is-err");
      addLog(`Start · ${name}`, msg, "is-err");
      return;
    }
    setStatus(name, "started", "is-ok");
    addLog(`Start · ${name}`, "run", "is-ok");
  }

  async function powerOff() {
    setStatus("Everything is off", "powering down…", "");
    await hub.setRunning(-1);
    if (hub.state.stateError) {
      const msg = hub.state.stateError.message || "power off failed";
      setStatus("Power off", msg, "is-err");
      addLog("Power off · all devices", msg, "is-err");
      return;
    }
    setStatus("Everything is off", "powered down", "is-ok");
    addLog("Power off · all devices", "run", "is-ok");
  }

  async function refresh() {
    els.statusNote.textContent = "reading hub state…";
    await hub.refreshState();
  }

  /* -- mode / lifecycle ------------------------------------------------------- */

  function ensureSelection() {
    const acts = hub.activities();
    if (acts.length) {
      const live = acts.find((a) => String(a["Id-"]) === hub.state.currentId);
      if (!selectedActivityId || !acts.some((a) => String(a["Id-"]) === selectedActivityId)) {
        selectedActivityId = String((live ?? acts[0])["Id-"]);
      }
    } else {
      selectedActivityId = "";
    }
    const devs = hub.devices();
    if (devs.length) {
      if (!selectedDeviceId || !devs.some((d) => d.id === selectedDeviceId)) {
        selectedDeviceId = devs[0].id;
      }
    } else {
      selectedDeviceId = "";
    }
  }

  function setMode(next) {
    if (mode === next) return;
    mode = next;
    els.segmented.querySelectorAll("[data-mode]").forEach((b) =>
      b.setAttribute("aria-pressed", String(b.dataset.mode === mode)));
    renderAll();
  }

  function renderNow() {
    if (!els.nowName) return;
    const id = hub.state.currentId;
    const running = id && id !== "-1";
    if (els.powerOff) els.powerOff.disabled = !running;
    if (!id) {
      els.nowEyebrow.textContent = "Now running";
      els.nowName.textContent = hub.state.stateError ? "State unavailable" : "Nothing running yet";
      els.nowMeta.textContent = hub.state.stateError?.message || "Start an activity from the list, or leave PowerOff as-is.";
      els.nowStrip?.classList.remove("is-live", "is-off");
      return;
    }
    if (id === "-1") {
      els.nowEyebrow.textContent = "Power";
      els.nowName.textContent = "Everything is off";
      els.nowMeta.textContent = "PowerOff is active";
      els.nowStrip?.classList.add("is-off");
      els.nowStrip?.classList.remove("is-live");
      return;
    }
    const activity = hub.activityById(id);
    els.nowEyebrow.textContent = "Now running";
    els.nowName.textContent = hub.activityName(activity);
    els.nowMeta.textContent = `${hub.activityTypeLabel(activity)} · ${id}`;
    els.nowStrip?.classList.add("is-live");
    els.nowStrip?.classList.remove("is-off");
  }

  function renderAll() {
    if (!mounted) return;
    ensureSelection();
    renderNow();
    renderSrcList();
    applyMapping();
  }

  mount();

  return {
    onShow(params) {
      const nextMode = params?.mode === "devices" ? "devices" : "activities";
      section.setAttribute("aria-label", nextMode === "devices" ? "Device remote" : "Activity remote");
      if (nextMode !== mode) setMode(nextMode);
      else renderAll();
    },
    onHide() {},
  };
}
/* Activities home: the remote's activity list for everyday use.
   Cards with run/edit/reorder/delete; setup always goes through the wizard.
   The vendored editor still exists at #editor for advanced fields. */

import * as hub from "../state.js";
import { deleteActivityGraph, reorderActivityGraph } from "../wizard-model.js";
import { setWizardEditId } from "./wizard.js";

const TEMPLATE = `
  <div class="view-head">
    <div>
      <h2 id="title-activities-home">Activities</h2>
      <p class="view-lead">Everything on the remote's screen. Run one, rework one, or set up a new one — setup is always guided.</p>
    </div>
    <div class="view-actions">
      <a class="btn btn-quiet" href="#editor">Advanced editor</a>
      <a class="btn btn-primary" href="#wizard">Set up a new activity</a>
    </div>
  </div>
  <p class="wiz-note" id="actNote" role="status" aria-live="polite"></p>
  <div id="actCards" class="act-list stagger"></div>`;

function escapeHtml(value) {
  return String(value ?? "").replace(/[&<>"']/g, (c) =>
    ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]);
}

export function createActivitiesHomeView(section) {
  let mounted = false;
  let els;
  let confirmDeleteId = "";

  function mount() {
    if (mounted) return;
    mounted = true;
    section.innerHTML = TEMPLATE;
    els = {
      cards: section.querySelector("#actCards"),
      note: section.querySelector("#actNote"),
    };
    section.addEventListener("click", onClick);
    hub.subscribe(render);
  }

  function setNote(text, isError = false) {
    els.note.textContent = text;
    els.note.classList.toggle("is-error", isError);
  }

  function buttonsFor(id) {
    const maps = hub.buttonMapsForActivity(id);
    return maps.reduce((count, m) =>
      count + (m.Buttons ?? []).filter((b) => b.ButtonAction?.CommandName).length, 0);
  }

  function card(a, index, total) {
    const id = String(a["Id-"]);
    const live = hub.state.currentId === id;
    const name = hub.activityName(a);
    const kind = hub.activityTypeLabel(a);
    const deviceCount = new Set((a.Roles ?? []).map((r) => String(r["DeviceId-"]))).size;
    const buttonCount = buttonsFor(id);
    const meta = `${kind} · ${deviceCount} device${deviceCount === 1 ? "" : "s"} · ${buttonCount} button${buttonCount === 1 ? "" : "s"}`;

    if (confirmDeleteId === id) {
      return `<div class="act-card is-confirming" data-card="${id}">
        <div class="act-confirm">
          <p><strong>Delete “${escapeHtml(name)}”?</strong> Its button setup goes with it. This can't be undone.</p>
          <div class="act-confirm-actions">
            <button type="button" class="btn btn-danger btn-sm" data-del-yes="${id}">Delete it</button>
            <button type="button" class="btn btn-quiet btn-sm" data-del-no>Keep it</button>
          </div>
        </div>
      </div>`;
    }

    return `<div class="act-card${live ? " is-live" : ""}" data-card="${id}" style="--i:${index}">
      <button type="button" class="act-main" data-edit="${id}" title="Open “${escapeHtml(name)}” in the setup wizard">
        <span class="act-name">${escapeHtml(name)}</span>
        <span class="act-meta">${escapeHtml(meta)}</span>
      </button>
      <span class="act-side">
        ${live
          ? `<span class="pill pill-live"><span class="live-dot" aria-hidden="true"></span>On air</span>`
          : `<button type="button" class="btn btn-quiet btn-sm" data-run="${id}">Run</button>`}
        <button type="button" class="btn btn-quiet btn-sm" data-edit="${id}">Set up</button>
        <span class="act-order" role="group" aria-label="Reorder ${escapeHtml(name)}">
          <button type="button" class="act-order-btn" data-move="-1" data-id="${id}" ${index === 0 ? "disabled" : ""} aria-label="Move up">↑</button>
          <button type="button" class="act-order-btn" data-move="1" data-id="${id}" ${index === total - 1 ? "disabled" : ""} aria-label="Move down">↓</button>
        </span>
        <button type="button" class="btn btn-quiet btn-sm act-del" data-del="${id}" ${live ? "disabled title=\"Power off before deleting\"" : ""}>Delete</button>
      </span>
    </div>`;
  }

  function render() {
    if (!mounted) return;
    const s = hub.state;
    if (!s.configLoaded) {
      els.cards.innerHTML = `<div class="state-block"><div class="skel" style="width:70%"></div><div class="skel"></div><div class="skel" style="width:55%"></div></div>`;
      return;
    }
    if (s.configError) {
      els.cards.innerHTML = `<div class="state-block">
        <span class="state-title">Could not load hub config</span>
        ${escapeHtml(s.configError.message)}
        <div style="margin-top:var(--space-3)"><button type="button" class="btn btn-secondary btn-sm" data-retry>Retry</button></div>
      </div>`;
      return;
    }
    const acts = hub.activities();
    if (!acts.length) {
      els.cards.innerHTML = `<div class="state-block">
        <span class="state-title">No activities yet</span>
        Set up your first one — it takes about a minute.
        <div style="margin-top:var(--space-4)"><a class="btn btn-primary" href="#wizard">Set up a new activity</a></div>
      </div>`;
      return;
    }
    els.cards.innerHTML = acts.map((a, i) => card(a, i, acts.length)).join("");
  }

  async function mutate(fn, busyNote) {
    setNote(busyNote);
    try {
      await fn({
        config: hub.state.config,
        revision: hub.state.config?.revision,
      });
      await hub.reloadConfig();
      setNote("");
    } catch (error) {
      setNote(`${error.message} — reloaded the latest config; try again.`, true);
      await hub.reloadConfig();
    }
  }

  function onClick(e) {
    const retry = e.target.closest("[data-retry]");
    if (retry) {
      hub.reloadConfig();
      return;
    }
    const delNo = e.target.closest("[data-del-no]");
    if (delNo) {
      confirmDeleteId = "";
      render();
      return;
    }
    const delYes = e.target.closest("[data-del-yes]");
    if (delYes) {
      const id = delYes.dataset.delYes;
      confirmDeleteId = "";
      mutate((ctx) => deleteActivityGraph({ ...ctx, id }), "Deleting…");
      return;
    }
    const del = e.target.closest("[data-del]");
    if (del && !del.disabled) {
      confirmDeleteId = del.dataset.del;
      render();
      return;
    }
    const move = e.target.closest("[data-move]");
    if (move && !move.disabled) {
      const { id, move: dir } = move.dataset;
      mutate((ctx) => reorderActivityGraph({ ...ctx, id, direction: dir }), "Saving order…");
      return;
    }
    const run = e.target.closest("[data-run]");
    if (run) {
      hub.setRunning(run.dataset.run);
      return;
    }
    const edit = e.target.closest("[data-edit]");
    if (edit) {
      setWizardEditId(edit.dataset.edit);
      location.hash = "#wizard";
    }
  }

  mount();

  return {
    onShow() {
      confirmDeleteId = "";
      hub.ensureConfig();
      hub.refreshState();
      render();
    },
    onHide() {},
  };
}
const TEMPLATE = `
  <div class="section-head">
    <div>
      <h2 id="title-activities">Advanced editor</h2>
      <div class="section-lead">Full-fidelity editing for power users: raw roles, per-surface button maps, and JSON. Most people should use the guided setup instead.</div>
    </div>
    <div class="actions">
      <a class="button" href="#activities">‹ All activities</a>
      <a class="button wiz-cta" href="#wizard">Guided setup</a>
      <button id="activityRefresh" type="button" class="secondary">Reload from hub</button>
    </div>
  </div>
  <div class="activity-command">
    <div class="activity-hero">
      <div>
        <div class="activity-eyebrow">Now running</div>
        <h3 id="activityCurrentName">Waiting for hub</h3>
        <div id="activityCurrentMeta" class="activity-current-meta"><span class="activity-live-dot"></span>Current state has not been read yet</div>
      </div>
      <div class="activity-hero-actions">
        <button id="activityRefreshState" type="button">Refresh state</button>
        <button id="activityPowerOff" type="button">Power everything off</button>
      </div>
    </div>
    <div id="activityNotice" class="activity-notice" role="status" aria-live="polite"></div>
    <div class="activity-layout">
      <aside class="panel activity-roster">
        <div class="activity-roster-head">
          <h3>Remote activity order</h3>
          <div class="help">This order is written back to ActivityList and shown on compatible Harmony remotes.</div>
          <div class="activity-roster-actions">
            <button id="activitySync" type="button" class="secondary">Refresh remote locally</button>
          </div>
        </div>
        <div id="activityList" class="activity-list">
          <div class="activity-list-empty">Open Activities to load the hub.</div>
        </div>
      </aside>
      <div class="activity-workspace">
        <div id="activityEmpty" class="panel activity-empty">
          <div>
            <div class="activity-empty-mark">&#9654;</div>
            <h3>Select an activity</h3>
            <div class="muted">Choose an activity from the ordered list to edit its advanced fields. New activities are created with the <a href="#wizard">guided setup</a>.</div>
          </div>
        </div>
        <div id="activityEditor" class="panel activity-editor hidden">
          <div class="activity-editor-head">
            <div>
              <div class="activity-eyebrow" style="color:var(--accent-primary)">Activity editor</div>
              <h3 id="activityEditorTitle">Activity</h3>
              <div id="activityEditorMeta" class="muted mini"></div>
            </div>
            <span id="activityDirty" class="activity-dirty">Unsaved</span>
          </div>
          <div class="activity-tabs" role="tablist">
            <button type="button" class="activity-tab active" data-activity-tab="setup">Devices &amp; inputs</button>
            <button type="button" class="activity-tab" data-activity-tab="buttons">Remote buttons</button>
            <button type="button" class="activity-tab" data-activity-tab="advanced">Advanced JSON</button>
          </div>
          <div class="activity-tab-panel active" data-activity-tab-panel="setup">
            <div class="activity-form-grid">
              <div><label for="activityName">Activity name</label><input id="activityName" maxlength="96"></div>
              <div><label for="activityType">Activity kind</label><select id="activityType"></select></div>
              <div><label for="activityIcon">Icon key</label><input id="activityIcon" placeholder="Optional firmware icon"></div>
              <div><label for="activityDefaultChannel">Default channel</label><input id="activityDefaultChannel" placeholder="Optional"></div>
              <div><label for="activityDefaultStation">Default station name</label><input id="activityDefaultStation" placeholder="Optional"></div>
            </div>
            <div class="activity-section-title">
              <div>
                <h4>Device roles and input routing</h4>
                <div class="help">Roles tell Harmony which device supplies picture, volume, channels, playback, or keyboard input.</div>
              </div>
              <button id="activityAddRole" type="button" class="secondary">Add device role</button>
            </div>
            <div id="activityRoleList" class="activity-role-list"></div>
          </div>
          <div class="activity-tab-panel" data-activity-tab-panel="buttons">
            <div class="callout"><strong>Map the paired remote per surface.</strong> Press, long-press, and double-press assignments are saved in MapList together with the activity.</div>
            <div class="activity-map-toolbar">
              <div><label for="activityMapSelect">Remote surface</label><select id="activityMapSelect"></select></div>
              <div class="actions"><button id="activityClearMap" type="button" class="danger">Clear this surface</button></div>
            </div>
            <div id="activityMapSummary" class="activity-map-summary">No map selected.</div>
            <datalist id="activityCommandCatalog"></datalist>
            <div id="activityButtonList" class="activity-button-list"></div>
          </div>
          <div class="activity-tab-panel" data-activity-tab-panel="advanced">
            <div class="callout"><strong>Full-fidelity editor.</strong> These objects preserve fields the guided editor does not expose, including entry/leave actions, control groups, sequence metadata, and firmware-specific values. Invalid JSON is never sent.</div>
            <div class="activity-raw-grid">
              <div><label for="activityRawActivity">Selected Activity object</label><textarea id="activityRawActivity" spellcheck="false"></textarea></div>
              <div><label for="activityRawMaps">Button maps for this Activity</label><textarea id="activityRawMaps" spellcheck="false"></textarea></div>
              <div class="activity-raw-functions"><label for="activityRawFunctions">Control-group FunctionMap for this Activity</label><textarea id="activityRawFunctions" spellcheck="false"></textarea></div>
            </div>
            <div class="actions">
              <button id="activityApplyRaw" type="button" class="secondary">Apply JSON to working copy</button>
              <a class="button secondary" href="/export/activities">Download ActivityList</a>
              <a class="button secondary" href="/export/maps">Download MapList</a>
              <a class="button secondary" href="/export/functions">Download FunctionList</a>
            </div>
          </div>
          <div class="activity-savebar">
            <div id="activitySaveState" class="activity-save-state">Hub resources match this editor</div>
            <div class="actions">
              <button id="activityRunSelected" type="button" class="ghost">Run</button>
              <button id="activityDuplicate" type="button" class="ghost">Duplicate</button>
              <button id="activityDelete" type="button" class="danger">Delete</button>
              <button id="activitySaveSync" type="button" class="secondary">Save &amp; refresh remote</button>
              <button id="activitySave" type="button">Save to hub</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>`;

let vendorPromise = null;

function ensureStylesheet(href, marker) {
  if (document.querySelector(`link[${marker}]`)) return;
  const link = document.createElement("link");
  link.rel = "stylesheet";
  link.href = href;
  link.setAttribute(marker, "1");
  document.head.appendChild(link);
}

function loadVendorAssets() {
  if (vendorPromise) return vendorPromise;
  vendorPromise = new Promise((resolve, reject) => {
    ensureStylesheet("vendor/activity-ui.css", "data-activity-vendor");
    ensureStylesheet("css/activity-overrides.css", "data-activity-overrides");
    if (document.querySelector("script[data-activity-vendor]")) {
      resolve();
      return;
    }
    const script = document.createElement("script");
    script.src = "vendor/activity-ui.js";
    script.dataset.activityVendor = "1";
    script.onload = () => resolve();
    script.onerror = () => reject(new Error("Could not load activity editor script"));
    document.body.appendChild(script);
  });
  return vendorPromise;
}

function triggerVendorReload() {
  document.getElementById("activityRefresh")?.click();
}

export function createActivitiesView(section) {
  section.innerHTML = TEMPLATE;

  return {
    async onShow() {
      section.classList.add("active");
      try {
        await loadVendorAssets();
        if (!section.dataset.vendorBooted) {
          section.dataset.vendorBooted = "1";
        } else {
          triggerVendorReload();
        }
      } catch (error) {
        section.innerHTML = `
          <div class="view-head">
            <div>
              <h2>Activities</h2>
              <p class="view-lead">The activity editor could not start.</p>
            </div>
          </div>
          <div class="notice notice-error" role="alert">
            <strong>Editor failed to load.</strong>
            <p>${error.message || "Unknown error"}</p>
            <p class="muted">Reload the page, or open Control to run activities without editing maps.</p>
            <p><a class="btn btn-secondary" href="#control">Open remote</a></p>
          </div>`;
      }
    },
    onHide() {
      section.classList.remove("active");
    },
  };
}
/* Guided activity setup: Basics → Devices → Buttons → Review.
   Writes genuine graph resources via wizard-model; the full editor remains
   the escape hatch for anything the wizard does not expose. */

import * as hub from "../state.js";
import { REMOTE_BUTTONS, BUTTON_KEY_BY_LABEL } from "../remote-layout.js";
import { ACTIVITY_TYPES, ROLE_TYPES, roleLabel, saveDraft } from "../wizard-model.js";

const STEPS = [
  { id: "basics", label: "Name it" },
  { id: "devices", label: "Pick devices" },
  { id: "buttons", label: "Map buttons" },
  { id: "review", label: "Review & save" },
];

const TEMPLATE = `
  <div class="view-head">
    <div>
      <h2 id="title-wizard">Activity setup</h2>
      <p class="view-lead">Four steps to a working activity: what it's called, which devices it uses, what the remote buttons do, then save. The full editor stays available for advanced fields.</p>
    </div>
    <div class="view-actions">
      <a class="btn btn-ghost" href="#activities">All activities</a>
      <a class="btn btn-ghost" href="#editor">Advanced editor</a>
    </div>
  </div>
  <ol class="wiz-rail" id="wizRail"></ol>
  <div class="wiz-body" id="wizBody"></div>
  <div class="wiz-foot" id="wizFoot">
    <p class="wiz-note" id="wizNote" role="status" aria-live="polite"></p>
    <div class="wiz-foot-actions">
      <button type="button" class="btn btn-ghost" id="wizBack">Back</button>
      <button type="button" class="btn btn-primary" id="wizNext">Continue</button>
    </div>
  </div>`;

function escapeHtml(value) {
  return String(value ?? "").replace(/[&<>"']/g, (c) =>
    ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]);
}

function prettifyInput(commandName) {
  const stripped = String(commandName).replace(/^Input/i, "");
  return stripped
    .replace(/([a-z])([A-Z])/g, "$1 $2")
    .replace(/([A-Za-z])(\d)/g, "$1 $2")
    .replace(/\bHdmi\b/g, "HDMI")
    .replace(/\bTv\b/g, "TV")
    .replace(/\bAv\b/g, "AV")
    .replace(/\bUsb\b/g, "USB")
    .replace(/\bArc\b/g, "ARC");
}

function inputOptions(device) {
  return (device?.commands ?? [])
    .filter((c) => /^(input|hdmi|source)/i.test(c.name))
    .map((c) => ({ value: prettifyInput(c.name), command: c.name }));
}

function emptyDraft() {
  return { name: "", type: 2, roles: [], buttons: {} };
}

let pendingEditId = "";

export function setWizardEditId(id) {
  pendingEditId = String(id ?? "");
}

export function createWizardView(section) {
  let mounted = false;
  let els;
  let step = 0;
  let draft = emptyDraft();
  let editId = "";
  let selectedKey = null; // remote-layout label currently being assigned
  let panelDeviceId = ""; // device chosen in the assign panel (survives re-renders)
  let saved = null; // { activityId, name } after a successful save

  function mount() {
    if (mounted) return;
    mounted = true;
    section.innerHTML = TEMPLATE;
    els = {
      rail: section.querySelector("#wizRail"),
      body: section.querySelector("#wizBody"),
      note: section.querySelector("#wizNote"),
      back: section.querySelector("#wizBack"),
      next: section.querySelector("#wizNext"),
    };
    els.back.addEventListener("click", () => go(step - 1));
    els.next.addEventListener("click", onNext);
    els.body.addEventListener("click", onBodyClick);
    els.body.addEventListener("change", onBodyChange);
    els.body.addEventListener("input", onBodyInput);
  }

  /* -- navigation --------------------------------------------------- */

  function go(next) {
    step = Math.max(0, Math.min(STEPS.length - 1, next));
    selectedKey = null;
    render();
  }

  function onNext() {
    const problem = validate(step);
    if (problem) {
      setNote(problem, true);
      return;
    }
    if (step < STEPS.length - 1) {
      go(step + 1);
    } else {
      save();
    }
  }

  function validate(which) {
    if (which === 0 && !draft.name.trim()) return "Give the activity a name to continue.";
    if (which === 1 && !draft.roles.length) return "Add at least one device to continue.";
    if (which === 1 && draft.roles.some((r) => !r.deviceId || !r.roleType)) {
      return "Every device row needs a device and a job.";
    }
    return "";
  }

  function setNote(text, isError = false) {
    els.note.textContent = text;
    els.note.classList.toggle("is-error", isError);
  }

  /* -- render --------------------------------------------------------- */

  function render() {
    els.rail.innerHTML = STEPS.map((s, i) => {
      const state = i < step ? "is-done" : i === step ? "is-current" : "";
      return `<li class="${state}">
        <span class="wiz-rail-dot">${i < step ? "✓" : i + 1}</span>
        <span class="wiz-rail-label">${s.label}</span>
      </li>`;
    }).join("");

    els.back.hidden = step === 0;
    els.next.hidden = false;
    els.next.textContent = step === STEPS.length - 1 ? "Save to hub" : "Continue";
    setNote("");

    if (step === 0) renderBasics();
    else if (step === 1) renderDevices();
    else if (step === 2) renderButtons();
    else renderReview();
  }

  function renderBasics() {
    els.body.innerHTML = `
      <section class="panel wiz-panel">
        <h3>${editId ? `Rework “${escapeHtml(draft.name)}”` : "What is this activity?"}</h3>
        <p class="help">${editId
          ? "Name, devices, and buttons below replace its current setup when you save; advanced fields you can't see here are preserved."
          : "Examples: “Movie night”, “Saturday games”, “Vinyl”. The name shows on the remote's screen."}</p>
        <label for="wizName">Activity name</label>
        <input id="wizName" maxlength="96" value="${escapeHtml(draft.name)}" placeholder="Movie night" autocomplete="off">
        <label>What kind of activity is it?</label>
        <div class="wiz-kinds" role="group" aria-label="Activity kind">
          ${ACTIVITY_TYPES.map((t) => `
            <button type="button" class="wiz-kind ${Number(draft.type) === t.value ? "is-selected" : ""}" data-kind="${t.value}" aria-pressed="${Number(draft.type) === t.value}">
              ${t.label}
            </button>`).join("")}
        </div>
      </section>`;
    section.querySelector("#wizName")?.focus();
  }

  function renderDevices() {
    const devices = hub.devices();
    els.body.innerHTML = `
      <section class="panel wiz-panel">
        <h3>Which devices take part?</h3>
        <p class="help">Add each device this activity uses and give it a job. Devices power on in the order you add them — if one is slow to wake, give it a power-on delay.</p>
        <div class="wiz-roles" id="wizRoles">
          ${draft.roles.map((role, i) => roleRow(role, i, devices)).join("")}
        </div>
        <button type="button" class="btn btn-secondary" data-wiz="add-role" ${draft.roles.length >= devices.length ? "disabled" : ""}>Add a device</button>
      </section>`;
  }

  function roleRow(role, i, devices) {
    const device = devices.find((d) => d.id === role.deviceId);
    const inputs = inputOptions(device);
    const usedIds = new Set(draft.roles.map((r) => r.deviceId));
    return `
      <div class="wiz-role" data-role-index="${i}">
        <div class="wiz-role-grid">
          <div>
            <label>Device</label>
            <select data-field="deviceId">
              <option value="">Choose a device…</option>
              ${devices.map((d) => `<option value="${d.id}" ${d.id === role.deviceId ? "selected" : ""} ${usedIds.has(d.id) && d.id !== role.deviceId ? "disabled" : ""}>${escapeHtml(d.name)}</option>`).join("")}
            </select>
          </div>
          <div>
            <label>Its job</label>
            <select data-field="roleType">
              <option value="">Choose a job…</option>
              ${ROLE_TYPES.map((r) => `<option value="${r.type}" ${r.type === role.roleType ? "selected" : ""}>${r.label}</option>`).join("")}
            </select>
          </div>
          <div>
            <label>Input on start</label>
            <select data-field="input" ${inputs.length ? "" : "disabled"}>
              <option value="">No input change</option>
              ${inputs.map((o) => `<option value="${escapeHtml(o.value)}" ${o.value === role.input ? "selected" : ""}>${escapeHtml(o.value)}</option>`).join("")}
            </select>
          </div>
          <div>
            <label>Power-on delay (ms)</label>
            <input data-field="powerDelay" inputmode="numeric" pattern="[0-9]*" placeholder="0" value="${escapeHtml(role.powerDelay ?? "")}">
          </div>
          <button type="button" class="btn btn-quiet btn-sm wiz-role-remove" data-wiz="remove-role" aria-label="Remove this device">Remove</button>
        </div>
        ${role.roleType ? `<p class="help">${ROLE_TYPES.find((r) => r.type === role.roleType)?.hint ?? ""}</p>` : ""}
      </div>`;
  }

  function renderButtons() {
    const mappedCount = Object.keys(draft.buttons).length;
    const assignable = REMOTE_BUTTONS.filter((b) => BUTTON_KEY_BY_LABEL[b.label]);
    els.body.innerHTML = `
      <section class="panel wiz-panel">
        <h3>What should the buttons do?</h3>
        <p class="help">Click a key on the remote, then pick the device and command it sends. Mapped keys glow. Skip anything you don't need — you can refine later in the full editor.</p>
        <div class="wiz-map">
          <div class="ir-remote-shell wiz-remote">
            <div class="ir-remote-skin" id="wizRemoteBody" role="group" aria-label="Harmony remote — pick a key to map">
              <img src="/assets/remote-skin.jpg" alt="Harmony remote control layout" width="591" height="1280" draggable="false">
              ${assignable.map((b) => {
                const key = BUTTON_KEY_BY_LABEL[b.label];
                const mapped = Boolean(draft.buttons[key]);
                return `<button type="button"
                  class="remote-hotspot wiz-key ${mapped ? "is-mapped" : ""} ${selectedKey === b.label ? "is-selected" : ""}"
                  data-key-label="${b.label}"
                  style="left:${b.x}%;top:${b.y}%;width:${b.w}%;height:${b.h}%"
                  aria-label="${b.label} — ${mapped ? "mapped" : "not mapped"}"
                  aria-pressed="${mapped}"></button>`;
              }).join("")}
            </div>
          </div>
          <div class="wiz-assign" id="wizAssign">
            ${selectedKey ? assignPanel() : `
              <div class="state-block">
                <span class="state-title">No key selected</span>
                Pick a key on the remote to assign it — ${mappedCount} of ${assignable.length} keys mapped so far.
              </div>`}
          </div>
        </div>
      </section>`;
  }

  function defaultAssignDevice() {
    const playback = draft.roles.find((r) => /Play|Channel/.test(r.roleType));
    return playback?.deviceId ?? draft.roles[0]?.deviceId ?? hub.devices()[0]?.id ?? "";
  }

  function assignPanel() {
    const key = BUTTON_KEY_BY_LABEL[selectedKey];
    const existing = draft.buttons[key];
    const devices = hub.devices();
    const deviceId = panelDeviceId || existing?.deviceId || defaultAssignDevice();
    const device = devices.find((d) => d.id === deviceId);
    const mappedCount = Object.keys(draft.buttons).length;
    return `
      <div class="wiz-assign-head">
        <h4>“${selectedKey}” sends…</h4>
        <span class="mono muted">${mappedCount} mapped</span>
      </div>
      <label for="wizAssignDevice">Device</label>
      <select id="wizAssignDevice">
        ${devices.map((d) => `<option value="${d.id}" ${d.id === deviceId ? "selected" : ""}>${escapeHtml(d.name)}</option>`).join("")}
      </select>
      <label for="wizAssignCommand">Command</label>
      <input id="wizAssignCommand" list="wizCommandList" placeholder="Type to search commands…" value="${escapeHtml(existing?.command?.name ?? "")}" autocomplete="off">
      <datalist id="wizCommandList">
        ${(device?.commands ?? []).map((c) => `<option value="${escapeHtml(c.name)}">`).join("")}
      </datalist>
      <div class="wiz-hold">
        <label class="wiz-hold-toggle" for="wizHoldToggle">
          <input type="checkbox" id="wizHoldToggle" ${existing?.hold ? "checked" : ""}>
          Holding the key does something else
        </label>
        <div id="wizHoldRow" ${existing?.hold ? "" : "hidden"}>
          <label for="wizHoldCommand">Hold command (same device)</label>
          <input id="wizHoldCommand" list="wizCommandList" placeholder="e.g. ${escapeHtml(existing?.command?.name ?? "Play")}" value="${escapeHtml(existing?.hold?.command?.name ?? "")}" autocomplete="off">
        </div>
      </div>
      <div class="wiz-assign-actions">
        <button type="button" class="btn btn-primary btn-sm" data-wiz="apply-key">Apply to “${selectedKey}”</button>
        ${existing ? `<button type="button" class="btn btn-quiet btn-sm" data-wiz="clear-key">Remove mapping</button>` : ""}
      </div>`;
  }

  function renderReview() {
    if (saved) {
      els.body.innerHTML = `
        <section class="panel wiz-panel wiz-done">
          <h3>“${escapeHtml(saved.name)}” is saved</h3>
          <p class="help">Written to the hub config and reloaded in the activity engine. It appears on the remote and in Control.</p>
          <div class="actions">
            <button type="button" class="btn btn-primary" data-wiz="run-saved">Run it now</button>
            <a class="btn btn-secondary" href="#control">Open remote</a>
            <a class="btn btn-quiet" href="#activities">All activities</a>
            <button type="button" class="btn btn-quiet" data-wiz="again">Set up another</button>
          </div>
        </section>`;
      els.next.hidden = true;
      els.back.hidden = true;
      setNote("");
      return;
    }
    els.next.hidden = false;
    const devices = hub.devices();
    const mapped = Object.entries(draft.buttons);
    els.body.innerHTML = `
      <section class="panel wiz-panel">
        <h3>Review “${escapeHtml(draft.name)}”</h3>
        <p class="help">${editId ? "Saving replaces this activity's setup in place." : "Saving adds a new activity at the end of the remote's list."}</p>
        <div class="wiz-review">
          <div class="wiz-review-card">
            <span class="eyebrow">Activity</span>
            <strong>${escapeHtml(draft.name)}</strong>
            <span class="muted">${ACTIVITY_TYPES.find((t) => t.value === Number(draft.type))?.label ?? "Activity"}</span>
          </div>
          <div class="wiz-review-card">
            <span class="eyebrow">Devices · ${draft.roles.length}</span>
            ${draft.roles.map((r) => {
              const d = devices.find((x) => x.id === r.deviceId);
              return `<span class="wiz-review-line"><strong>${escapeHtml(d?.name ?? r.deviceId)}</strong> — ${roleLabel(r.roleType)}${r.input ? ` · ${escapeHtml(r.input)}` : ""}${r.powerDelay ? ` · ${r.powerDelay}ms delay` : ""}</span>`;
            }).join("")}
          </div>
          <div class="wiz-review-card">
            <span class="eyebrow">Buttons · ${mapped.length}</span>
            ${mapped.length ? mapped.map(([key, m]) => {
              const d = devices.find((x) => x.id === m.deviceId);
              return `<span class="wiz-review-line"><strong>${key}</strong> → ${escapeHtml(d?.name ?? m.deviceId)} · ${escapeHtml(m.command.name)}${m.hold?.command ? ` (hold: ${escapeHtml(m.hold.command.name)})` : ""}</span>`;
            }).join("") : `<span class="wiz-review-line muted">No buttons mapped — the activity still runs, and you can map keys later in the full editor.</span>`}
          </div>
        </div>
      </section>`;
  }

  /* -- events --------------------------------------------------------- */

  function onBodyClick(e) {
    const kindBtn = e.target.closest("[data-kind]");
    if (kindBtn) {
      draft.type = Number(kindBtn.dataset.kind);
      els.body.querySelectorAll(".wiz-kind").forEach((b) => {
        const on = b === kindBtn;
        b.classList.toggle("is-selected", on);
        b.setAttribute("aria-pressed", String(on));
      });
      return;
    }
    const keyEl = e.target.closest(".wiz-key");
    if (keyEl) {
      selectedKey = keyEl.dataset.keyLabel;
      panelDeviceId = draft.buttons[BUTTON_KEY_BY_LABEL[selectedKey]]?.deviceId ?? defaultAssignDevice();
      renderButtons();
      return;
    }
    const act = e.target.closest("[data-wiz]")?.dataset.wiz;
    if (!act) return;
    if (act === "add-role") {
      const devices = hub.devices();
      const free = devices.find((d) => !draft.roles.some((r) => r.deviceId === d.id));
      draft.roles.push({ deviceId: free?.id ?? "", roleType: "", input: "", powerDelay: "" });
      renderDevices();
    } else if (act === "remove-role") {
      const row = e.target.closest("[data-role-index]");
      draft.roles.splice(Number(row.dataset.roleIndex), 1);
      renderDevices();
    } else if (act === "apply-key") {
      applyKey();
    } else if (act === "clear-key") {
      delete draft.buttons[BUTTON_KEY_BY_LABEL[selectedKey]];
      renderButtons();
    } else if (act === "run-saved" && saved) {
      hub.setRunning(saved.activityId).then(() => { location.hash = "#control"; });
    } else if (act === "again") {
      draft = emptyDraft();
      editId = "";
      saved = null;
      go(0);
    }
  }

  function onBodyChange(e) {
    const field = e.target.dataset.field;
    if (field) {
      const row = e.target.closest("[data-role-index]");
      const role = draft.roles[Number(row.dataset.roleIndex)];
      if (role) {
        role[field] = e.target.value;
        if (field === "deviceId" || field === "roleType") renderDevices();
      }
      return;
    }
    if (e.target.id === "wizHoldToggle") {
      section.querySelector("#wizHoldRow").hidden = !e.target.checked;
      return;
    }
    if (e.target.id === "wizAssignDevice") {
      panelDeviceId = e.target.value;
      renderButtons();
    }
  }

  function onBodyInput(e) {
    if (e.target.id === "wizName") draft.name = e.target.value;
  }

  function pickStart(id) {
    if (!id) {
      editId = "";
      draft = emptyDraft();
      renderBasics();
      return;
    }
    const activity = hub.activityById(id);
    if (!activity) return;
    editId = id;
    draft = emptyDraft();
    draft.name = hub.activityName(activity);
    draft.type = Number(activity.Type ?? 1);
    draft.roles = (activity.Roles ?? []).map((r) => ({
      deviceId: String(r["DeviceId-"]),
      roleType: String(r.__type ?? ""),
      input: r.SelectedInput?.Name ?? "",
      powerDelay: r.NextDevicePowerOnDelay ?? "",
    }));
    const maps = hub.buttonMapsForActivity(id);
    const surface = maps.find((m) => /^16414Activity/.test(String(m?.ButtonMapIdentifier ?? ""))) ?? maps[0];
    for (const b of surface?.Buttons ?? []) {
      if (!b.ButtonKey || !b.ButtonAction?.CommandName) continue;
      draft.buttons[b.ButtonKey] = {
        deviceId: String(b.ButtonAction["DeviceId-"]),
        command: { name: b.ButtonAction.CommandName, functionId: b.ButtonAction["FunctionId-"] },
        hold: b.ButtonLongPressAction?.CommandName
          ? {
              deviceId: String(b.ButtonLongPressAction["DeviceId-"]),
              command: { name: b.ButtonLongPressAction.CommandName, functionId: b.ButtonLongPressAction["FunctionId-"] },
            }
          : null,
      };
    }
    renderBasics();
  }

  function applyKey() {
    const deviceId = section.querySelector("#wizAssignDevice").value || panelDeviceId;
    const commandName = section.querySelector("#wizAssignCommand").value.trim();
    const device = hub.deviceById(deviceId);
    const command = device?.commands.find((c) => c.name === commandName);
    if (!command) {
      setNote(`“${commandName || "?"}” is not a command of ${device?.name ?? "that device"} — pick one from the list.`, true);
      return;
    }
    const holdOn = section.querySelector("#wizHoldToggle").checked;
    const holdName = holdOn ? section.querySelector("#wizHoldCommand").value.trim() : "";
    let hold = null;
    if (holdName) {
      const holdCommand = device.commands.find((c) => c.name === holdName);
      if (!holdCommand) {
        setNote(`Hold command “${holdName}” is not a command of ${device.name}.`, true);
        return;
      }
      hold = { deviceId, command: { name: holdCommand.name, functionId: holdCommand.functionId } };
    }
    draft.buttons[BUTTON_KEY_BY_LABEL[selectedKey]] = {
      deviceId,
      command: { name: command.name, functionId: command.functionId },
      hold,
    };
    setNote("");
    renderButtons();
  }

  async function save() {
    els.next.disabled = true;
    setNote("Saving to the hub…");
    try {
      const outcome = await saveDraft({
        config: hub.state.config,
        revision: hub.state.config?.revision,
        draft,
        editId: editId || null,
      });
      saved = { activityId: outcome.activityId, name: outcome.name };
      await hub.reloadConfig();
      renderReview();
    } catch (error) {
      setNote(`Save failed: ${error.message}`, true);
    } finally {
      els.next.disabled = false;
    }
  }

  mount();

  return {
    async onShow() {
      await hub.ensureConfig();
      draft = emptyDraft();
      editId = "";
      saved = null;
      step = 0;
      if (pendingEditId && hub.activityById(pendingEditId)) {
        pickStart(pendingEditId);
      }
      pendingEditId = "";
      render();
    },
    onHide() {},
  };
}
import * as hub from "./state.js";
import { createDashboardView } from "./views/dashboard.js";
import { createControlView } from "./views/control.js";
import { createActivitiesHomeView } from "./views/activities-home.js";
import { createActivitiesView } from "./views/activities.js";
import { createWizardView } from "./views/wizard.js";
import { createPlaceholderView, PLACEHOLDER_PAGES } from "./views/placeholder.js";

const TITLES = {
  home: "Home",
  control: "Control",
  devices: "Devices",
  activities: "Activities",
  editor: "Advanced editor",
  wizard: "Activity setup",
  ir: "IR setup",
  bluetooth: "Bluetooth",
  mqtt: "MQTT",
  wifi: "Wi-Fi",
  backup: "Backup",
  system: "System",
};

const routes = {};

function register(route, sectionId, factory) {
  const section = document.getElementById(sectionId);
  routes[route] = { route, section, view: factory(section) };
}

function registerPlaceholder(route) {
  const spec = PLACEHOLDER_PAGES[route];
  const navIcon = document.querySelector(`.nav-link[data-route="${route}"] svg`);
  register(route, `view-${route}`, (section) =>
    createPlaceholderView(section, { ...spec, icon: navIcon ? navIcon.outerHTML : "" }));
}

register("home", "view-home", createDashboardView);
register("control", "view-control", createControlView);
register("activities", "view-activities-home", createActivitiesHomeView);
register("editor", "view-activities", createActivitiesView);
register("wizard", "view-wizard", createWizardView);
for (const route of ["ir", "bluetooth", "mqtt", "wifi", "backup", "system"]) {
  registerPlaceholder(route);
}

/* Devices is the Control view in device mode (same handset, direct IR). */
routes.devices = { ...routes.control, route: "devices", params: { mode: "devices" } };

let current = null;

function routeFromHash() {
  const hash = location.hash.replace(/^#/, "");
  return routes[hash] ? hash : "control";
}

function show(route) {
  const next = routes[route];

  if (current && current.section !== next.section) {
    current.section.hidden = true;
    current.section.classList.remove("active");
    current.view.onHide?.();
  }

  if (current?.section !== next.section || next.section.hidden) {
    next.section.hidden = false;
    next.section.classList.add("active");
  }

  document.querySelectorAll(".nav-link").forEach((link) => {
    if (link.dataset.route === route) link.setAttribute("aria-current", "page");
    else link.removeAttribute("aria-current");
  });

  next.view.onShow?.(next.params);
  document.title = `${TITLES[route] ?? "Control"} · Harmony Hub Control`;
  current = next;
}

/* -- Top-bar live chip ------------------------------------------------- */

const liveChip = document.getElementById("topLiveChip");
const liveName = document.getElementById("topLiveName");

hub.subscribe((s) => {
  if (!liveChip || !liveName) return;
  if (s.currentId === "-1") {
    liveChip.hidden = false;
    liveChip.classList.remove("pill-live");
    liveChip.classList.add("pill-dim");
    liveChip.querySelector(".live-dot")?.remove();
    liveName.textContent = "Everything is off";
  } else if (s.currentId) {
    liveChip.hidden = false;
    liveChip.classList.add("pill-live");
    liveChip.classList.remove("pill-dim");
    if (!liveChip.querySelector(".live-dot")) {
      liveChip.insertAdjacentHTML("afterbegin", `<span class="live-dot" aria-hidden="true"></span>`);
    }
    const activity = hub.activityById(s.currentId);
    liveName.textContent = activity ? hub.activityName(activity) : `Activity ${s.currentId}`;
  } else {
    liveChip.hidden = true;
  }
});

/* -- Boot ---------------------------------------------------------------- */

window.addEventListener("hashchange", () => show(routeFromHash()));

if (!routes[location.hash.replace(/^#/, "")]) {
  history.replaceState(null, "", "#control");
}
show(routeFromHash());

hub.ensureConfig();
hub.refreshState();
